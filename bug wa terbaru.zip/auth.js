const kodeBenar = "STARWHYVIPVIP"; // Ganti jika perlu

function login() {
  const input = document.getElementById("kode").value;
  if (input === kodeBenar) {
    localStorage.setItem("auth", "ok");
    window.location.href = "index.html";
  } else {
    document.getElementById("login-status").innerText = "❌ Kode salah!";
  }
}

// Validasi saat akses index.html
if (window.location.pathname.includes("index.html")) {
  if (localStorage.getItem("auth") !== "ok") {
    window.location.href = "login.html";
  }
}
