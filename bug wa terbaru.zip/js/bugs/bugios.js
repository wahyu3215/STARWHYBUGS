(function(){
  const target = localStorage.getItem("bug_target");
  if (!target) return alert("Target belum diatur!");
  alert("🚀 Menjalankan BUG: BUGIOS ke " + target);
  // Tambahkan efek kirim bug di sini
})();
